<?php
/**
 * Blog post content media template
 *
 * @package vogue
 * @since 1.0.0
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<h3 class="entry-title">
		<a href="<?php the_permalink(); ?>" title="<?php echo the_title_attribute( 'echo=0' ); ?>" rel="bookmark"><?php the_title(); ?></a>
	</h3>
		<?php echo presscore_get_posted_on(); ?>
		    <div class="view-count">
		<?php echo do_shortcode("[hit_count]");?>
		
		<div class="social-icons">
						<div class="blogshare">
				
									<div class="social">
										
										  <div class="social__item"  data-service="facebook">
										     <span class="fa fa-facebook" data-saurce="<?php the_permalink(); ?>" data-social="fb"></span>
										  </div>
										    <div class="social__item"  data-service="twitter">
										    <span class="fa fa-twitter" data-saurce="<?php the_permalink(); ?>" data-social="tw"></span>
										  </div>
										  <div class="social__item"  data-saurce="<?php the_permalink(); ?>" data-service="linkedin">
										       <span class="fa fa-linkedin" data-saurce="<?php the_permalink(); ?>" data-social="ln"></span>
										  </div>
										  <div class="social__item"  data-service="pinterest">
										   <span class="fa fa-pinterest" data-saurce="<?php the_permalink(); ?>" data-social="pt"></span>
										  </div>
									</div>  
			  
							</div>

			</div>
			</div>
<?php
// check show or not media content
if ( presscore_show_post_media() ): ?>

	<div class="blog-media wf-td" <?php echo presscore_get_post_content_style_for_blog_list( 'media' ); ?>>

	<?php
	/////////////////
	// fancy date //
	/////////////////

	echo presscore_get_blog_post_fancy_date();

	/////////////////////
	// media template //
	/////////////////////

	 presscore_get_template_part( 'theme', "blog/list/blog-list-post-media-content", get_post_format() );
	?>

	</div>

<?php endif; ?>
